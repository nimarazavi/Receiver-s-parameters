%plot

a = ls;

for ii = 3:49
    splotter(a(ii,:)); hold on;
    %cmrr(a(ii,:)); hold on;
end
