function splotter(filename)

s = sparameters(filename);
fmhz = s.Frequencies./1e6;

S11 = rfparam(s,1,1);
S21 = rfparam(s,2,1);
S12 = rfparam(s,1,2);
S22 = rfparam(s,2,2);
S31 = rfparam(s,3,1);
S32 = rfparam(s,3,2);
S33 = rfparam(s,3,3);
S23 = rfparam(s,2,3);
S13 = rfparam(s,1,3);

%figure;
plot(fmhz, 20*log10(abs(S21)), fmhz, 20*log10(abs(S23))); grid on; hold on;
plot(fmhz, 20*log10(abs(S11)), fmhz, 20*log10(abs(S33))); hold off;
legend('S21 (A)','S23 (B)','S11 (A)','S33 (B)'); ylim([-30 90]);
title(filename); shg